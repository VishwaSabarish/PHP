<?php
/* Smarty version 3.1.30, created on 2016-10-17 15:52:13
  from "C:\xampp\htdocs\Sabarish\Test\templates\test.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5804d78d8c1fe6_93783330',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0d305b4234a3453849ca4ca295563f9b0c862d52' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Sabarish\\Test\\templates\\test.tpl',
      1 => 1476712328,
      2 => 'file',
    ),
  ),
  'cache_lifetime' => 120,
),true)) {
function content_5804d78d8c1fe6_93783330 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
<head>
  <title>Hello World!</title>
</head>
<body>
  Hello this is working

<br /><br />
<!-- html table -->
<table border="1">
    <tr style="background:lightblue">
    <td>bigbang</td>
    <td>120mins</td>
  </tr>
    <tr style="background:azure">
    <td>watchdogs</td>
    <td>115mins</td>
  </tr>
    <tr style="background:lightblue">
    <td>teser</td>
    <td>120mins</td>
  </tr>
  
</table>

<!-- build in html table func-->
<table border='0'>
<tbody>
<tr>
<td>test1</td>
</tr>
<tr>
<td>test2</td>
</tr>
<tr>
<td>test3</td>
</tr>
</tbody>
</table>

</body>
</html>
<?php }
}
