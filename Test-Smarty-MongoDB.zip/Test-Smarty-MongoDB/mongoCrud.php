<?php
    // Load All Dependentcies
    require 'vendor/autoload.php';

    // MongoDB Connection Client.
    $dbClient = new MongoDB\Client;

    // Create Or Select CompanyDB.
    $companyDB = $dbClient->companyDB;

    // Drop or Delete database.
    $delDatabase = $dbClient->dropDatabase('employeecollection');

    // List All database in MongoDB.
    foreach ($dbClient->listDatabases() as $database) {
      var_dump($database);
    }

    //Create employee Collection (or Table).
    $employeeCollection = $companyDB->createCollection('employeecollection');
    var_dump($employeeCollection);

    // Select Collection or Table.
    $employeeCollection = $companyDB->employeecollection;

    // List all Tables
    foreach ($companyDB->listCollections() as $table) {
      var_dump($table);
    }

    // Drop or Delete Collection (table).
    $delResult = $companyDB->dropCollections('employeecollection');
    var_dump($delResult);

    // Insert document (or Row) to Collection (or Table).
    // Command Name: insertOne.
    // Description : Insert only Single Document (or Row) with Specific.
    // Option(s)   : Objects (or Fields) in Array.
    $insertOneResult = $employeeCollection->insertOne(
      ['_id' => '1', 'name' => 'Andrew', 'age' => '26', 'skill' => 'mongoDB']
    );

    // Command Name: getInsertedCount
    // Description : Get Total documents (or rows) Inserted Count.
    printf("Inserted %d documents", $insertOneResult->getInsertedCount());

    // Command Name: getInsertedId.
    // Description : Get Inserted Document (or row) Id.
    var_dump($insertOneResult->getInsertedId());

    // Insert Multiple documents (or Rows) to Collection (or Table).
    // Command Name: insertMany.
    // Description : Insert Many Documents (or Rows) with Specific.
    // Option(s)   : Objects (or Fields) in Array within Array.
    $insertManyResult = $employeeCollection->insertMany([
      ['_id' => '2', 'name' => 'Brad', 'age' => '26', 'skill' => 'mongoDB'],
      ['_id' => '3', 'name' => 'Chris', 'age' => '30', 'skill' => 'nodejs'],
      ['_id' => '4', 'name' => 'Debbie', 'age' => '22', 'skill' => 'angular']
    ]);

    // Command Name: getInsertedCount
    // Description : Get Total documents (or rows) Inserted Count.
    printf("Inserted %d documents", $insertManyResult->getInsertedCount());

    // Command Name: getInsertedIds.
    // Description : Get all Inserted Documents (or rows) Ids.
    var_dump($insertManyResult->getInsertedIds());

    // Insert document (or Row) to Collection (or Table).
    // Command Name: findOne.
    // Description : find One (or Select Single) Document (or Row) from Collection (or Table).
    // Option(s)   : Objects (or Fields) in Array.
    $document = $employeeCollection->findOne(
      ['_id' => '1']
    );

    var_dump($document);

    // Command Name: find.
    // Description : find (or Select) Documents (or Rows) from Collection (or Table).
    // Option(s)   : Objects (or Fields) in Array [Optional].
    $documentlist = $employeeCollection->find(
      ['skill' => 'mongoDB']
    );

    // Command Name: find.
    // Description : find (or Select) Documents (or Rows) from Collection (or Table).
    // Option(s)   : Objects (or Fields) in Array [Optional] and with other Optional Array of [projection](*For select particular Columns or Fields With Columns name as Associvative Array with positionno ).
    $documentlist = $employeeCollection->find(
      ['skill' => 'mongoDB'],
      //key             column,  no  column,  no
      ['projection' => ['_id' => 0, 'name' => 1]]
    );

    // Command Name: find.
    // Description : find (or Select) Documents (or Rows) from Collection (or Table).
    // Option(s)   : Objects (or Fields) in Array [Optional] and
    // with other Optional Array of [setting](like limit,skip,sort ).
    $documentlist = $employeeCollection->find(
      [],
      [
          'limit' => 4,
          'skip' => 2,
          // key     column   Desc -1 ,Asc 1
          'sort' => ['age' => -1]
      ]
    );

    foreach($documentlist as $doc)
    {
      var_dump($doc);
    }

    // Update document (or Row) to Collection (or Table).
    // Command Name: updateOne.
    // Description : update One (or Select Single) Document (or Row) from Collection (or Table).
    // Option(s)   : Selctions Fields (or where) Objects (or Fields) in Array and Secount is Set with Fields (or update values).
    $updateResult = $employeeCollection->updateOne(
      ['name' => 'Andrew'],
      ['$set' => ['age' => '29']]
    );

    // Update document (or Row) to Collection (or Table).
    // Command Name: updateMany.
    // Description : update multiple Documents (or Rows) from Collection (or Table).
    // Option(s)   : Selctions Fields (or where) Objects (or Fields) in Array[optional] and Secount is Set with Fields (or update values)[require].
    $updateResult = $employeeCollection->updateMany(
      ['skill' => 'mongoDB'],
      ['$set' => ['age' => '28']]
    );

    // Update document (or Row) to Collection (or Table).
    // Command Name: replaceOne.
    // Description : replace entire Document(s) (or Row(s)) from Collection (or Table).
    // Option(s)   : Selctions Fields (or where) Objects (or Fields) in Array[optional] and Secount is new Fields with (or update values)[require].
    $replaceResult = $employeeCollection->replaceOne(
      // serch critiria
      ['_id' => '4'],
      // new Document (or row)
      ['_id' => '4', 'favColor' => 'blue']
    );

    // Command Name: getMatchedCount.
    // Description : Get matched Documents (or Rows) with the contition Count from Collection (or Table).
    printf("Matched %d documents \n", $replaceResult->getMatchedCount());

    // Command Name: getModifiedCount.
    // Description : Get modified Document (or Row) Count.
    printf("Modified %d documents \n", $replaceResult->getModifiedCount());

    // Delete document (or Row) to Collection (or Table).
    // Command Name: deleteOne.
    // Description : Delete single Document (or Row from Collection (or Table).
    // Option(s)   : Selctions Fields (or where) Objects (or Fields) in Array[optional] and Secount is new Fields with (or update values)[require].
    $deleteResult = $employeeCollection->deleteOne(
      // serch critiria
      ['_id' => '4']
    );

    // Delete document (or Row) to Collection (or Table).
    // Command Name: deleteMany.
    // Description : Delete multiple Document(s) (or Row(s)) from Collection (or Table).
    // Option(s)   : Selctions Fields (or where) Objects (or Fields) in Array[optional] and Secount is new Fields with (or update values)[require].
    $deleteResult = $empcollection->deleteMany(
      // serch critiria
      ['name' => 'Ethan']
    );

    // Command Name: getDeletedCount.
    // Description : Get deleted Document (or Row) Count.
    printf("Deleted %d documents", $deleteResult->getDeletedCount());

    // Command Name: iterator_to_array.
    // Description : Copy the iterator into an array.
    $resultArray = iterator_to_array($replaceResult);
    var_dump($resultArray);
?>
