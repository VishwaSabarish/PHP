<?php
    // Load All Dependentcies
    require 'vendor/autoload.php';

    $smarty = new Smarty;
    $smarty->caching = true;
    $smarty->cache_lifetime = 120;
    $smarty->template_dir = './templates';
    $smarty->compile_dir = './templates_c';

    $msg = "Hello this is working";
    $title = "Hello World!";
    $movies = array('bigbang' => '120mins','watchdogs' => '115mins','teser' => '120mins' );
    $test = array('test1', 'test2','test3' );

    $smarty->assign("title",$title);
    $smarty->assign("message",$msg);
    $smarty->assign("movies",$movies);
    $smarty->assign("testtable",$test);

    $smarty->display("test.tpl");
?>
