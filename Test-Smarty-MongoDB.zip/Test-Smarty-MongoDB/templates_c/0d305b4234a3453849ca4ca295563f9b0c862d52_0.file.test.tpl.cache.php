<?php
/* Smarty version 3.1.30, created on 2016-10-17 15:52:13
  from "C:\xampp\htdocs\Sabarish\Test\templates\test.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5804d78d62a017_36481450',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0d305b4234a3453849ca4ca295563f9b0c862d52' => 
    array (
      0 => 'C:\\xampp\\htdocs\\Sabarish\\Test\\templates\\test.tpl',
      1 => 1476712328,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5804d78d62a017_36481450 (Smarty_Internal_Template $_smarty_tpl) {
if (!is_callable('smarty_function_cycle')) require_once 'C:\\xampp\\htdocs\\Sabarish\\Test\\vendor\\smarty\\smarty\\libs\\plugins\\function.cycle.php';
if (!is_callable('smarty_function_html_table')) require_once 'C:\\xampp\\htdocs\\Sabarish\\Test\\vendor\\smarty\\smarty\\libs\\plugins\\function.html_table.php';
$_smarty_tpl->compiled->nocache_hash = '99085804d78d599e43_63360248';
?>
<html>
<head>
  <title><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
</title>
</head>
<body>
  <?php echo $_smarty_tpl->tpl_vars['message']->value;?>


<br /><br />
<!-- html table -->
<table border="1">
  <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['movies']->value, 'movielength', false, 'movietitle');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['movietitle']->value => $_smarty_tpl->tpl_vars['movielength']->value) {
?>
  <tr style="background:<?php echo smarty_function_cycle(array('values'=>'lightblue,azure'),$_smarty_tpl);?>
">
    <td><?php echo $_smarty_tpl->tpl_vars['movietitle']->value;?>
</td>
    <td><?php echo $_smarty_tpl->tpl_vars['movielength']->value;?>
</td>
  </tr>
  <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

</table>

<!-- build in html table func-->
<?php echo smarty_function_html_table(array('loop'=>$_smarty_tpl->tpl_vars['testtable']->value,'cols'=>1,'table_attr'=>"border='0'"),$_smarty_tpl);?>

</body>
</html>
<?php }
}
